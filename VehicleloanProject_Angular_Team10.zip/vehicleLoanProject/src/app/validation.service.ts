import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Registration } from './registration/registration';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  baseURL="http://localhost:8080/";
  constructor(private myHttp: HttpClient) { }

  RegisterService(regis: Registration)  {
    console.log('Service:inserting loan from spring');
    return this.myHttp.post(this.baseURL+"addJPAUser",regis);
  }

  validateDate() {
    console.log('date validation');
  }
  validatePhone(){
    console.log('Phone Validation');
  }
  validateUsername(uname:string){
    console.log('Frstname Validation');
  }
}