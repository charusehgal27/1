import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';
import { User } from '../user-login/User';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  constructor(private userProfile:ProfileService) { }

  emailID:string;
  firstname:string;
  ngOnInit(): void {
 this.emailID=sessionStorage.getItem('emailId');
this.firstname=sessionStorage.getItem('firstName');
  } 
   // mynum:number;
  // myemail:string;
    MyProfile:User;
  MyDetails(){
    console.log('MyDetails() works as its invoked.......');
    this.userProfile.MyDetailsService(this.emailID).
    subscribe((data:User)=>{
      this.MyProfile=data;
      console.log(this.MyProfile);     
 },
 (err)=>{
   console.log(err);
 }
 );}
  }


