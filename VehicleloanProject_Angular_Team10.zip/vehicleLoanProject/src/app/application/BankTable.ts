import { CibilTable } from "./CibilTable";

export class BankTable {
    accNumber: number;
	ifscCode: string;
    cibilTable: CibilTable= new CibilTable();
}