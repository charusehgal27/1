import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationService } from '../application.service';
import { ApplicationTable } from './ApplicationTable';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit {

  getEmail:string;

  constructor(private applicationService: ApplicationService,private route:Router) { }

  ngOnInit(): void {
  }
  insertAnApplication: ApplicationTable= new ApplicationTable();
  
  
  
  insertApplication() {
    console.log('inserting insertAnApplication()');
    this.getEmail=sessionStorage.getItem("emailId");
    this.applicationService.insertApplicationService(this.insertAnApplication,this.getEmail).subscribe();
    alert('Your Application is successfully submitted');
    this.route.navigate(['userdashboard']);
  }
 
pFee() {
  if(0.02*this.insertAnApplication.loanTable.loanAmount<15000)
   {
     this.insertAnApplication.loanTable.processingFee=0.02*this.insertAnApplication.loanTable.loanAmount;
   }
   else{
     this.insertAnApplication.loanTable.processingFee=15000;
   }
  
}
 rateOfInterest(){
   if(this.insertAnApplication.loanTable.loanTenure>0 && this.insertAnApplication.loanTable.loanTenure<=3){
     this.insertAnApplication.loanTable.rateOfInterest=9;
   }
   else if(this.insertAnApplication.loanTable.loanTenure>3 && this.insertAnApplication.loanTable.loanTenure<=5){
    this.insertAnApplication.loanTable.rateOfInterest=7.5;
  }
  else if(this.insertAnApplication.loanTable.loanTenure>5 && this.insertAnApplication.loanTable.loanTenure<=8){
    this.insertAnApplication.loanTable.rateOfInterest=6;
  }
  else{
    alert('Invalid Tenure');
  }
    

 }

}
