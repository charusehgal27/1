export class VehicleTable {
    carCompany: string;
            carModel: string;
            onRoadPrice: Number;
            showroomPrice: Number;
}