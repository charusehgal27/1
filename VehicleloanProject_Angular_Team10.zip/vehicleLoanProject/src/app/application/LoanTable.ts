export class LoanTable {
    loanAmount: number;
    loanTenure: number;
    processingFee: number;
    rateOfInterest: number;

}