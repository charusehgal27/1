import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  firstName:string;
  constructor(private route:Router) { }
  redirect(){
    
    
      sessionStorage.removeItem('userId');
      sessionStorage.removeItem('userPassword');
      sessionStorage.removeItem('address');
      sessionStorage.removeItem('age');
      sessionStorage.removeItem('city');
      sessionStorage.removeItem('emailId');
      sessionStorage.removeItem('firstName');
      sessionStorage.removeItem('gender');
      sessionStorage.removeItem('lastName');
      sessionStorage.removeItem('middleName');
      sessionStorage.removeItem('mobileNumber');
      sessionStorage.removeItem('pincode');
      sessionStorage.removeItem('state');
    this.route.navigate(['/home']);
  }
  ngOnInit(): void {
    this.firstName=sessionStorage.getItem('firstName');
  }

}
