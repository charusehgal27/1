import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loan-offer',
  templateUrl: './loan-offer.component.html',
  styleUrls: ['./loan-offer.component.css']
})
export class LoanOfferComponent implements OnInit {

  loanAmt:number;
  tenure:number;
  rateOfInterest:number;
  emi:number;
  pfee:number;
  firstName: string;

  calculateData(){
    this.emi=(this.loanAmt*this.rateOfInterest/(12*100)*Math.pow(1+this.rateOfInterest/(12*100),this.tenure*12))/ (Math.pow(1+this.rateOfInterest/(12*100),this.tenure*12)-1);
    if(0.02*this.loanAmt<15000)
     {
       this.pfee=0.02*this.loanAmt;
     }
     else{
       this.pfee=15000;
     }
    console.log('emi: ',this.emi);
    console.log('processing fee', this.pfee);
  }
  constructor(private route:Router) { }

  ngOnInit(): void {
    this.firstName=sessionStorage.getItem('firstName');
  }

  Applynow(){
       this.route.navigate(['application']);
  }
}
