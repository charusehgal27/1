import { Component, OnInit } from '@angular/core';
import { LoanService } from '../loan.service';
import { ApplicationTable } from './ApplicationTable';
import { Loans } from './Loans';

@Component({
  selector: 'app-my-loans',
  templateUrl: './my-loans.component.html',
  styleUrls: ['./my-loans.component.css']
})
export class MyLoansComponent implements OnInit {

  constructor(private loanService:LoanService) { }

  
  mynum:number;
  MyloanById:Loans;
  getMyloans(){
    console.log("getMyloans() is invoked");
    this.loanService.getMyLoanService(this.mynum).
    subscribe((data:Loans)=>{
         this.MyloanById=data;
         console.log(this.MyloanById);     
    },
    (err)=>{
      console.log(err);
    }
    );}
    /*allApps: ApplicationTable[] = [];
    myemail:string;
    
    loadAllApplication() {
      console.log('loadAllApplications() invoking loadAllApplicationService()');
      this.loanService.loadAllApplicationsByEmailService(this.myemail).subscribe(
        (data: ApplicationTable[])=> { this.allApps = data; console.log(this.allApps);}, 
        (err) => { console.log(err);}
      ); //end of subscribe 
    }*/
    
    ngOnInit(): void {
     // this.myemail=sessionStorage.getItem('emailId');
    }
  

}
