
export class Loans{
     loanId: number;
     loanAmount:number;
     loanTenure:number;
     processingFee:number;
     rateOfInterest:number;   
}