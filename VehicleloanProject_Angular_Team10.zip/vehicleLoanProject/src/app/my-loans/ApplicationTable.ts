import { BankTable } from "./BankTable";
import { EmploymentTable } from "./EmploymentTable";
import { LoanTable } from "./LoanTable";
import { VehicleTable } from "./VehicleTable";
import { DatePipe } from '@angular/common'


export class ApplicationTable {

        dateOfApplication=Date.now(); 
        dateOfApproval=Date.now(); 
        loanStatus: string="Pending";
        vehicleTable: VehicleTable=new VehicleTable();
        employmentTable: EmploymentTable= new EmploymentTable();
        loanTable: LoanTable=new LoanTable();
        bankTable: BankTable= new BankTable();
        
}