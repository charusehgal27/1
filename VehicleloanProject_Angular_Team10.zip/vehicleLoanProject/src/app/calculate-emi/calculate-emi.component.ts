import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculate-emi',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})
export class CalculateEmiComponent implements OnInit {

  loanAmt:number;
  roi:number;
  tenure:number;
  emi:number;

  calculateEMI(){
    this.emi=(this.loanAmt*this.roi/(12*100)*Math.pow(1+this.roi/(12*100),this.tenure*12))/ (Math.pow(1+this.roi/(12*100),this.tenure*12)-1);
    console.log('emi: ',this.emi);
  }
  constructor() { }

  ngOnInit(): void {
  }

}
