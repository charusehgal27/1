import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from './user-login/User';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  baseurl="http://localhost:8080/";

  constructor(private http:HttpClient) { }

  loginService(email:String,pass:String)
  {
    console.log('verifying the user');
    return this.http.get<User>(this.baseurl+"verifyUser/"+email+"/"+pass);
  }
  
}
