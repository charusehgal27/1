import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { IvyCarouselModule } from 'angular-responsive-carousel';
import { GetEligibilityComponent } from './get-eligibility/get-eligibility.component';
import { CalculateEmiComponent } from './calculate-emi/calculate-emi.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';

import { UserLoginComponent } from './user-login/user-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { RegistrationComponent } from './registration/registration.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MyLoansComponent } from './my-loans/my-loans.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { ApplicationComponent } from './application/application.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
   
    GetEligibilityComponent,
    CalculateEmiComponent,
    LoanOfferComponent,
    LoginComponent,
    UserLoginComponent,
    AdminLoginComponent,
    RegistrationComponent,
    UserDashboardComponent,
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    MyLoansComponent,
    UserProfileComponent,
    ApplicationComponent,
  
   
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    IvyCarouselModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
