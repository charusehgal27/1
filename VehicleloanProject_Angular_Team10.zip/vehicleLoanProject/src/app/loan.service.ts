import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicationTable } from './my-loans/ApplicationTable';
import { Loans } from './my-loans/Loans';

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  baseURL: string = 'http://localhost:8080/';
  constructor(private myhttp:HttpClient) { }
 

  getMyLoanService(num:number): Observable<Loans> {
    return this.myhttp.get<Loans>(this.baseURL+"getJPALoan/"+num);
  }
 /* loadAllApplicationsByEmailService(email:string) : Observable<ApplicationTable[]>  {
    console.log('Service: loading all Applications from spring');
    return this.myhttp.get<ApplicationTable[]>(this.baseURL+"getApplicationByemail/");}*/
  
}
