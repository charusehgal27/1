export class User
{
    userId:any;
    address:any;
    age:any;
    city:any;
    emailId:any;
    firstName:any;
    gender:any;
    lastName:any;
    middleName:any;
    mobileNumber:any;
    pincode:any;
    state:any;
    userPassword:any;
}
