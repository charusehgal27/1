import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { User } from './User';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  emailId:string;
  userPassword:string;
  message:string="Enter the correct Email Id and Password";
  
  myUser:User=new User();
  constructor(private service:UserserviceService,private route:Router) { } //
    

  //UserCredentials: Login=new Login();
  //CheckUser:Login=new Login();
  login() {
    console.log('loadEmployment() invoking loadEmploymentService()',this.emailId,this.userPassword);
    this.service.loginService(this.emailId,this.userPassword).subscribe(
    (data:User)=>{ this.myUser=data;
      console.log(this.emailId);
      console.log(this.userPassword);
       
      let userId=this.myUser.userId;
      let emailId=this.myUser.emailId;
      let firstName=this.myUser.firstName;
      let middleName=this.myUser.middleName;
      let lastName=this.myUser.lastName;
      let address=this.myUser.address;
      let age=this.myUser.age;
      let city=this.myUser.city;
      let userPassword=this.myUser.userPassword;
      let gender=this.myUser.gender;
      let mobileNumber=this.myUser.mobileNumber;
      let pincode=this.myUser.pincode;
      let state=this.myUser.state;

      sessionStorage.setItem('userId',userId);
      sessionStorage.setItem('firstName',firstName);
      sessionStorage.setItem('emailId',emailId);
      sessionStorage.setItem('userPassword',userPassword);
      sessionStorage.setItem('address',address);
      sessionStorage.setItem('age',age);
      sessionStorage.setItem('city',city);
      sessionStorage.setItem('gender',gender);
      sessionStorage.setItem('lastName',lastName);
      sessionStorage.setItem('middleName',middleName);
      sessionStorage.setItem('mobileNumber',mobileNumber);
      sessionStorage.setItem('pincode',pincode);
      sessionStorage.setItem('state',state);


      console.log(userId);
      this.route.navigate(['/userdashboard']);
    },
      (err)=>{console.log(err);
        alert(this.message);
      }
    );

    //this.UserServiceService.loginService(this.CheckUser).subscribe(); //end of subscribe 

  }
  ngOnInit(): void {
  }

}
