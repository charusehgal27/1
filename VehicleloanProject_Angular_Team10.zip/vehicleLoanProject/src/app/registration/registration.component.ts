import { Component, OnInit } from '@angular/core';
import { Registration } from './registration';
import * as moment from 'moment';
import { ValidationService } from '../validation.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  newRegistration: Registration = new Registration();
  repass: string;
  year = '';
  current = '';
  flag = false;

  constructor(private route: Router,private vs: ValidationService) { }

  registerUser(){
    console.log('ResgiterUser() invoking RegisterService()');
    this.vs.RegisterService(this.newRegistration).subscribe(); //end of subscribe 
     this.route.navigate(['login'])
  }

  check() {
  /*  this.current = moment(new Date()).format('YYYY');
    this.year = moment(this.newRegistration.age).format('YYYY');


    if ((Number(this.current) - Number(this.year) < 18) && Number(this.year) > 1970) {
      this.flag = false;

    }*/
    if(this.newRegistration.age<18){
      this.flag=false;

    }
    else if (this.newRegistration.firstName.length < 3 || this.newRegistration.firstName.length > 15) {
      this.flag = false;
    }
  /*  else if (this.newRegistration.mobileNumber.length != 10) {
      this.flag = false;
    }*/
    else if (this.newRegistration.emailId.length < 2) {
      this.flag = false
    }
    else {
      this.flag = true;
    }


  }
  validatForm() {
    this.vs.validateUsername(this.newRegistration.firstName);
  }

  onSubmit() {
    this.registerUser();
    console.log(this.newRegistration);

  }
  

  ngOnInit(): void {
  }

}