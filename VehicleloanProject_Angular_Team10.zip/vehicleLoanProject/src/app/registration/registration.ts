export class Registration {
    user_id:string;
    address:string;
    age:number;
    emailId: string;
    firstName: string;
    lastName: string;
    gender: string;
    middleName: string;
    mobileNumber: number;
    pincode: number;
    state: string;
    userPassword: string;
    city:string;
}