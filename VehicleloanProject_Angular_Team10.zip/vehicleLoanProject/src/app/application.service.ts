import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApplicationTable } from './application/ApplicationTable';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  constructor(private myHttp: HttpClient) { }
  baseURL="http://localhost:8080/";

  insertApplicationService(newApp: ApplicationTable,getEmail:string) {
    console.log('inserting Application to spring');
    return this.myHttp.post(this.baseURL+"addJPAApplication/"+getEmail,newApp);
  }
}
