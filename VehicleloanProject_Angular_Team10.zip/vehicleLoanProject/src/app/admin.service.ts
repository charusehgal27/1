import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicationTable } from './admin-dashboard/ApplicationTable';
import { UserTable } from './admin-dashboard/UserTable';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  baseURL="http://localhost:8080/";
  constructor(private myHttp: HttpClient) { }

  loadAllUsersService() : Observable<UserTable[]>  {
    console.log('Service: loading all Clients from spring');
    return this.myHttp.get<UserTable[]>(this.baseURL+"getJPAUsers/");
  }
  loadAllApplicationsService() : Observable<ApplicationTable[]>  {
    console.log('Service: loading all Applications from spring');
    return this.myHttp.get<ApplicationTable[]>(this.baseURL+"getJPAApplications/");
  }

  approveLoan(appId:number){
      return this.myHttp.post(this.baseURL+"acceptLoanApplication/"+appId, appId);
  }

  rejectLoan(appId:number){
    return this.myHttp.post(this.baseURL+"rejectLoanApplication/"+appId, appId);
  }

}
