import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { ApplicationComponent } from './application/application.component';
import { CalculateEmiComponent } from './calculate-emi/calculate-emi.component';
import { GetEligibilityComponent } from './get-eligibility/get-eligibility.component';
import { HomeComponent } from './home/home.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { LoginComponent } from './login/login.component';
import { MyLoansComponent } from './my-loans/my-loans.component';
import { RegistrationComponent } from './registration/registration.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';

import { UserLoginComponent } from './user-login/user-login.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: '', redirectTo:'home', pathMatch:'full'},
  { path:'calculateEmi', component: CalculateEmiComponent},
  { path:'login',component:LoginComponent},
  { path:'userlogin',component:UserLoginComponent},
  { path:'adminlogin',component:AdminLoginComponent},
  { path:'userdashboard',component:UserDashboardComponent},
  { path: 'application', component:ApplicationComponent},
  { path:'myloans',component:MyLoansComponent},
  { path:'profile',component:UserProfileComponent},
  { path:'admindashboard', component:AdminDashboardComponent},
  { path:'eligibility',component:GetEligibilityComponent },
  { path:'loanOffer',component:LoanOfferComponent},
  { path:'userRegisteration',component:RegistrationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
