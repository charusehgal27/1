import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user-login/User';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  baseURL: string = 'http://localhost:8080/';
  constructor(private myhttp:HttpClient) { }

  /*MyDetailsbyIdService(num:number):Observable<User>{
    return this.myhttp.get<User>(this.baseURL+"getJPAUser/"+num);
  }*/
  MyDetailsService(email:string):Observable<User>{
    return this.myhttp.get<User>(this.baseURL+"getUsers/"+email);
  }
}
