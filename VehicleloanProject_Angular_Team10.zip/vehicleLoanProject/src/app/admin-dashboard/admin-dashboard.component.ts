import { Component, OnInit } from '@angular/core';
import { UserTable } from './UserTable';
import { AdminService } from '../admin.service';
import { ApplicationTable } from './ApplicationTable';


@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor(private adminService:AdminService) { }

  
  allUsers: UserTable[] = [];
  loadAllUsers() {
    console.log('loadAllUsers() invoking loadAllDepartmentsService()');
    this.adminService.loadAllUsersService().subscribe(
      (data: UserTable[])=> {  this.allUsers = data; console.log(this.allUsers);}, 
      (err) => { console.log(err);}
    ); //end of subscribe 
  }

  allApps: ApplicationTable[] = [];
  loadAllApplication() {
    console.log('loadAllApplications() invoking loadAllApplicationService()');
    this.adminService.loadAllApplicationsService().subscribe(
      (data: ApplicationTable[])=> { this.allApps = data; console.log(this.allApps);}, 
      (err) => { console.log(err);}
    ); //end of subscribe 
  }

  //updateApplication: ApplicationTable = new ApplicationTable();
  // public appId:number;
  approveLoan(appId){
    //this.updateApplication.applicationId = appId;
    console.log(appId);
    this.adminService.approveLoan(appId).subscribe(
      data => {
         appId= data;
      }
    );
  }

  rejectLoan(appId){
    //this.loanId=loanId;
    console.log(appId);
    this.adminService.rejectLoan(appId).subscribe(
      data => {
          appId= data;
      }
    );
  }


  ngOnInit(): void {
  }

}
