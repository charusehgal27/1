export class LoanTable {
    loanAmount: Number;
    loanTenure: Number;
    processingFee: Number;
    rateOfInterest: Number;

}