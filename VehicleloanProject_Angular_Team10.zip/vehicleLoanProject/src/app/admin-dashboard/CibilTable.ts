export class CibilTable {

    pancardNumber: string;
	cibilScore: number;
    
}