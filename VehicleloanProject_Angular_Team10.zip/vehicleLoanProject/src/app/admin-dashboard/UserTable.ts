export class UserTable {
    firstName: string;
    MiddleName: string;
    lastName: string;
    age: number;
    gender: string;
    mobileNumber: Number;
    emailId: string;
    userPassword: string;
    address: string;
    state: string;
    city: string;
    pincode: number;
   
   }