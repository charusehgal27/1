import { CibilTable } from "./CibilTable";

export class BankTable {
    bankId:number;
    accNumber: number;
	ifscCode: string;
    cibilTable: CibilTable= new CibilTable();
}