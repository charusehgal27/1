export class EmploymentTable {
    annualSalary: Number;
            empType: String;
            existingEmi: Number;
}