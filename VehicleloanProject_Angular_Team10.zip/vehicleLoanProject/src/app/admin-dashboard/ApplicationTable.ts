import { BankTable } from "./BankTable";
import { EmploymentTable } from "./EmploymentTable";
import { LoanTable } from "./LoanTable";
import { VehicleTable } from "./VehicleTable";
import { DatePipe } from '@angular/common'
import { UserTable } from "./UserTable";


export class ApplicationTable {

        dateOfApplication: Date;
        applicationId: number;

        public datepipe: DatePipe;
        myFunction() {
                this.dateOfApplication = new Date();
                let latest_date = this.datepipe.transform(this.dateOfApplication, 'yyyy-MM-dd');
        }

        dateOfApproval: Date;
        loanStatus: string = "Pending";

        vehicleTable: VehicleTable = new VehicleTable();
        employmentTable: EmploymentTable = new EmploymentTable();
        userTable: UserTable = new UserTable();
        loanTable: LoanTable = new LoanTable();
        bankTable: BankTable = new BankTable();

}