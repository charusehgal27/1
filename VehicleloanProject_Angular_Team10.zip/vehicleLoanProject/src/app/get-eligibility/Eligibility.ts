export class Eligibility{  
        carMake: string;
        carModel: string;
        showroomPrice: number;
        onRoadPrice: number;
        name: string;
        age:number;
        salary:number;
        exsistingEmi:number;
        mobileNumber:number;
        email:string;  
}