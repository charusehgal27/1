import { Component, OnInit } from '@angular/core';
import { Eligibility } from './Eligibility';
import { AbstractControl, FormGroup,  FormBuilder,  Validators } from '@angular/forms';

@Component({
  selector: 'app-get-eligibility',
  templateUrl: './get-eligibility.component.html',
  styleUrls: ['./get-eligibility.component.css']
})
export class GetEligibilityComponent implements OnInit {

  form: FormGroup;
  cm:string;
  submitted = false;
  carMake = true;
  carModel = true;
  showroomPrice = true;
  onRoadPrice = true;
  Name = false;
  Age = false;
  Salary = true;
  exsistingEmi = true;
  mobileNumber = false;
  Email = false;
  applied = false;  

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group(
      {
        name: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        number: ['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
      },
      {
        //validators: [Validation.match('password', 'confirmPassword')]
      }
    );
    this.cm='no name';
    this.newEligibility.carMake = '';
    this.newEligibility.carModel = '';
    this.newEligibility.showroomPrice = 0;
    this.newEligibility.onRoadPrice = 0;
    this.newEligibility.name = '';
    this.newEligibility.age = 0;
    this.newEligibility.salary = 0;
    this.newEligibility.exsistingEmi = 0;
    this.newEligibility.mobileNumber = 0;
    this.newEligibility.email = '';
  }
  get formControls(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  newEligibility: Eligibility = new Eligibility(); 

  checkEligibility(){
    console.log("On Submit");
    if(this.newEligibility.exsistingEmi > 0.2 * this.newEligibility.salary){
      console.log("Loan Would be Very High for You");
      alert('You are not eligible as emi is greater than 20% of emi ')
      return;
    }
    else{
      alert('you are eligible you can login to apply for loan')
    }

    console.log(this.cm);
    console.log(this.newEligibility.carMake);
    console.log(this.newEligibility.carModel);
    console.log(this.newEligibility.showroomPrice);
    console.log(this.newEligibility.onRoadPrice);
    console.log(this.newEligibility.name);
    console.log(this.newEligibility.age);
    console.log(this.newEligibility.salary);
    console.log(this.newEligibility.exsistingEmi);
    console.log(this.newEligibility.salary);
    console.log("User Details Passes Validation , Eligible to take Loan");
  }
  /*digit(number){
    temp=number;
    while(temp)
  }*/
  check1(){
    this.Age = true;
  }
  check(){
    console.log("Printing the values")
    console.log(this.cm);
    console.log(this.newEligibility.carMake);
    console.log(this.newEligibility.carModel);
    console.log(this.newEligibility.showroomPrice);
    console.log(this.newEligibility.onRoadPrice);
    console.log(this.newEligibility.name);
    console.log(this.newEligibility.age);
    console.log(this.newEligibility.salary);
    console.log(this.newEligibility.exsistingEmi);
    console.log(this.newEligibility.salary);
      if(this.newEligibility.age < 18){
        console.log("Age should be greater then 18");
        this.submitted=false;
      }
      else if (this.newEligibility.name.length < 5 || this.newEligibility.name.length > 15) {
        console.log("Name Should have atleast Lenght : 5");
        this.Name = true;
        this.submitted = false;
      }
      else if (this.newEligibility.mobileNumber < 1000000000) {
        console.log("Mobile Number Should have Digits : 10");
        this.mobileNumber = true;
        this.submitted = false;
      }
      else if (this.newEligibility.email.length < 5) {
        console.log("Email should be having Length > 5");
        this.Email = true;
        this.submitted = false;
      }
      else {
        this.submitted = true;
      }

      if(this.newEligibility.age < 18){
        console.log("Age is less then 18")
        this.Age=false;
      }
      else{
        console.log("Age is greater then 18");
        this.Age=true;
      }

      if (this.newEligibility.name.length < 5 || this.newEligibility.name.length > 15) {
        this.Name = false;
      }
      else if (this.newEligibility.name.length >= 5) {
        this.Name = true;
      }

      if (this.newEligibility.mobileNumber < 1000000000) {
        this.mobileNumber = true;
      }
      else if (this.newEligibility.mobileNumber >= 1000000000){
        this.mobileNumber = true;
      }

      if (this.newEligibility.email.length < 5) {
        this.Email = false;
      }
      else if (this.newEligibility.email.length > 5) {
        this.Email = true;
      }
    }
  checkcarMakeInput(){

  }
  validateFormsUsername(){

  }
}